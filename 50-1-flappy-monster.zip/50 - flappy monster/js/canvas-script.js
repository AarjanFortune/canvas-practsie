

window.onload = function() {

  var canvas = document.getElementById('flappy-monster-game');


};
