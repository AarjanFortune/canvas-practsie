


/**
 *
 * bar.js
 * simple, elegant bar chart library
 * {date} - version 1.0
 * {url}
 *
 * Copyright 2017 {your name}
 * Relased under the MIT License
 * {license url}
 *
 */

'use strict';

function BarChart(targetId, width, height, data){

  console.log(arguments);


}
